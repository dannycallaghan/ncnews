//import Logo from "../Images/my-logo-2.png";

function Header() {
  return (
    <section className="Header">
      <p>Logo</p>
    </section>
  );
}

export default Header;
