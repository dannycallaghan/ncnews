function Footer() {
  return (
    <section className="Footer">
      <p>&copy; 2022</p>
    </section>
  );
}

export default Footer;
