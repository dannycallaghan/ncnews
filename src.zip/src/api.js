const apiServer = 'https://nc-news-example-3.herokuapp.com/api';

const Api = {
  get_topics: `${apiServer}/topics`,
  get_articles: `${apiServer}/articles`,
};

export default Api;